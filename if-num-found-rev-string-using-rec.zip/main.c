#include<stdio.h>
void str_rev(char *,char *);
void main()
{int i,j=0,c;
    char ch[50]="abcd e13fd sndjf";
    for(i=0;ch[i];i++)
    {if(ch[i]==' ')
      j=i;
        if(ch[i]>='0' && ch[i]<='9')
        {
            break;
        }
    }
    for(c=j+1;ch[c];c++)
    {
        if(ch[c]==' ')
        break;
    }
    str_rev((ch+(j+1)),(ch+(c-1)));
    printf("%s",ch);
    
    
}
void str_rev(char *p,char *q)
{char t;
    if(p<q)
    {
        t=*p;
        *p=*q;
        *q=t;
        p++;
        q--;
        str_rev(p,q);
    }
    else
    return;
}