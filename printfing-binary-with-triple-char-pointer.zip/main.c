#include<stdio.h>
void main()
{
    float f=23.5;
    char *p=&f,**q=&p,***w=&q;
    for(**w=**w+3;**w>=&f;**w=**w-1)
    {
        for(int i=7;i>=0;i--)
        printf("%d",(***w>>i)&1);
    }
    
}