#include<stdio.h>
void string(int *);
void main()
{
    int a[5];
    for(int i=0;i<5;i++)
    scanf("%d",&a[i]);
    string(a);
}
void string(int *p)
{
    char a[30],r,r1,r2;
    int temp,len=0,c=0;
    for(int i=0;i<5;i++)
    {temp=p[i];
    for(c=0;temp;temp=temp/10)
    c++;
    temp=p[i];
    if(c==2){
     while(temp)
     {
         r=(temp%10)+48;
         temp=temp/10;
         r1=(temp%10)+48;
         temp=temp/10;
         a[len++]=r1;
         a[len++]=r;
     }
     
    }
    else if(c==3)
    {
         while(temp)
     {
         r=(temp%10)+48;
         temp=temp/10;
         r1=(temp%10)+48;
         temp=temp/10;
         r2=(temp%10)+48;
         temp=temp/10;
         a[len++]=r2;
         a[len++]=r1;
         a[len++]=r;
     }
     
    }
    }
    a[len]='\n';
    printf("%s",a);
    
}