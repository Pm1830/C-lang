/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  unsigned short int num,r1;
   short int *p,*q;
   p=&num;
   q=&num;
   printf("enter the number =");
   scanf("%hx",&num);
    r1=*q&0x0ff0;
   *p=(*p<<12)|(*p>>12);
   num=*p|r1;
   printf("%hx",num);
}