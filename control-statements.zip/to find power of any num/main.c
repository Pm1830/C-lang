/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int c=0,num;
  printf("enter the number ");
  scanf("%d",&num);
  if(num==0)
  printf("the power is 0");
  if(num%2==0)
  {for(;num,num%2==0;)
  {c++;
  num=num/2;}
}  else 
 { printf("not a pow of 2");}
  printf("pow is =%d",c);
}