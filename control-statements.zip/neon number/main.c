#include<stdio.h>
void main()
{
    int num,t,sum,r;
    printf("enter the number =");
    scanf("%d",&num);
    for(t=num,sum=0;t;t=t/10)
 {   r=t%10;
    sum=sum+r;
 }
 sum=sum*sum;
 if(sum==num)
 printf("its neon number");
 else
 printf("not a neon number");
}