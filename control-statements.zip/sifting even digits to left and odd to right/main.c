#include<stdio.h>
void main()
{
    int num,temp,r,r1,sum,abc,c;
    printf("enter the num=");
    scanf("%d",&num);
    for(temp=num,c=1;temp;temp=temp/10)
    {r=temp%2;
    if(r%2==0)
        c=c*10;
    }
    for(temp=num,sum=0,r1=0;temp;temp=temp/10)
    {
        r=temp%10;
    if(r%2==0)
        sum=sum*10+r;
    else if(r%2==1)
    r1=r1*10+r;
    }
    temp=r1+(sum*c);
    printf("new num=%d old num=%d ",temp,num);
}
