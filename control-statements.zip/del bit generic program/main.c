#include<stdio.h>
void main()
{
    unsigned int num,r;
    int i,d,pos;
    printf("enter the hex number =");
    scanf("%d",&num);
    printf("enter the number of bit you want to delete=");
    scanf("%d",&d);
    printf("from which bit you want to delete=");
    scanf("%d",&pos);
    for(i=31;i>=0;i--)
    printf("%d",num>>i&1);
    printf("\n");
    
    r=num<<(32-pos);
    r=r>>(32-pos);
    num=num>>(pos+d);
    num=num<<(pos);
    num=num|r;
    
    for(i=31;i>=0;i--)
    printf("%d",num>>i&1);
    printf("\n");
    printf("new number =%d",num);
}