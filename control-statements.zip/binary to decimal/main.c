#include<stdio.h>
void main()
{
    int a,b,c=1,num=0,r;
    printf("enter the binary=" );
    scanf("%d",&a);
    for(;a;a=a/10)
    {
        r=a%10;
        num=num+(r*c);
        c=c*2;
    }
    printf("%d",num);
}