#include<stdio.h>
void main()
{
    char ch[20]="vector india",*p=ch;
    int sum=0,i,c=0,temp,r=0,r1=0,mul=0,c1;
    int pos=0;
        while(*p)
        {
            c++;
            if(p[i]==32)
            {
                sum=sum*10+(c-1);
                c=0;
            }
            else if(p[i+1]=='\0')
            temp=c;
            p++;
        }
    sum=sum*10+temp;
    printf("%d\n",sum);
    r=sum%10;
    for(sum;sum;pos=pos+4,sum=sum/10)
    {c1++;
        r1=sum%10;
        if(c1>1)
        {
            r=r|(r1<<pos);
        }
    }
    
    printf("0x");
    printf("%x",r);
}