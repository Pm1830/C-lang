#include<stdio.h>
#include<stdlib.h>
void main()
{
    int row,i,col;
    char **p;
    printf("enter thr num of strings=");
    scanf("%d",&row);
    printf("enter thr col of strings=");
    scanf("%d",&col);
    p=malloc(sizeof(char *)*row);
    for(i=0;i<row;i++)
    p[i]=malloc(sizeof(char)*col);
     printf("enter strings=\n");
    for(i=0;i<row;i++)
    scanf("%s",p[i]);
    
    for(i=0;i<row;i++)
    printf("%s\n",p[i]);

}