/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    unsigned int num,r1,r2;
    printf("enter the number=");
    scanf("%X",&num);
    r1=num<<24;
    r1=r1>>16;
    r2=num>>8;
    num=r1|r2;
    printf("%X",num);
}