#include<stdio.h>
void main()
{
    int num1,num2;
    printf("enter the num1=");
    scanf("%d",&num1);
    printf("enter the num2=");
    scanf("%d",&num2);
    num1^num2?printf("not same"):printf("same");
}