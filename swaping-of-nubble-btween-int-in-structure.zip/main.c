#include<stdio.h>
#include<stdlib.h>
struct st {
	int a;
	int b;
	int c;
};
void swap (struct st **);
void main()
{
	struct st *v=0;
	swap(&v);
	printf("%x %x",v->a,v->c);
}
void swap(struct st **p)
{
	struct st *q;
	int temp1,temp;
	q=malloc(sizeof(struct st));
	scanf("%x %x",&q->a,&q->c);
	temp=q->a;
	temp1=q->c;
	temp=temp&0x0000000f;
     q->a=q->a&0xfffffff0;
	temp1=temp1&0x0000000f;
	q->c=(q->c&0xfffffff0);
	q->a=(q->a|temp1);
	q->c=(q->c|temp);
	*p=q;


}
