#define pf printf
#define sf scanf
char *strstrstr(char *p,char *q)
{int i,c,j,a;
    
        for(i=0;p[i];i++)
        if(p[i]==q[0])
        {   
            a=i;
            break;
        }
            for(j=i+1,c=1;q[c];c++,j++)
        {   
            if(p[j]==q[c])
            continue;
            else 
            return NULL;
        }
        
    
     return (p+a);
     
}