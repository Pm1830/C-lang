#include<stdio.h>
#include"header.h"
void main()
{
    char s[50],a[50];
    char *p;
    pf("enter the string=");
    sf("%[^\n]",s);
    pf("enter the sub-string=");
    sf(" %[^\n]",a);
    p=strstrstr(s,a);
    printf("%s",p);
    
}