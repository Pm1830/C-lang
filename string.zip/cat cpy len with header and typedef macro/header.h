int len(char *s)
{
    int i;
    for(i=0;s[i];i++);
    return i;
}
void cpy(char *s,char *p)
{
    while(*p)
    {
        *p++=*s++;
    }
}
void cat(char *s,char *o)
{   int c,j,a;
    c=len(s);
    //printf("%d\n",c);
    for(j=c,a=0;o[a];a++,j++)
    {
        s[j]=o[a];
    }
}