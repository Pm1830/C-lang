#include<stdio.h>
#include"header.h"
typedef char string;
#define pf printf
#define sf scanf
void main()
{
    string s[50],p[50];
    int c;
    pf("enter the string=");
    sf("%[^\n]",s);
    pf("enter the sub string=");
    sf(" %[^\n]",p);
    c=len(s);
   cpy(s,p);
    cat(s,p);
    pf("len=%d\n",c);
  pf("new string=%s\n",p);
    pf("cat string=%s",s);

    
    
}