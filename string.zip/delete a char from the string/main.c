#include<stdio.h>
void main()
{
    char a[50],ch;
    int i,j;
    printf("enter the string=");
    scanf("%s",a);
    printf("enter the char=");
    scanf(" %c",&ch);
    for(i=0;a[i];i++)
    {
        if(ch==a[i])
        {for(j=i;a[j];j++)
            a[j]=a[j+1];
            i--;
        }
    }
    printf("%s",a);
}