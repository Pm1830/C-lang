#include<stdio.h>
void main()
{
    char s[10],ch;
    int in,i,len;
    printf("enter the string:");
    scanf("%s",s);
    printf("enter the index where you want to add char:");
    scanf("%d",&in);
    printf("enter the char you wnat to add:");
    scanf(" %c",&ch);
    for(len=0;s[len];len++);
    for(i=len+1;i>in;i--)
    s[i]=s[i-1];
    s[in]=ch;
    printf("%s",s);
}