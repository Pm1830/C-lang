#include<stdio.h>
void main()
{
    char s[50];
    int i,j;
    printf("enter the string=");
    scanf("%s",s);
    for(i=0;s[i];i++)
    {
        if(s[i]>=48 && s[i]<=59)
        {for(j=i;s[j];j++)
            s[j]=s[j+1];
            i--;
        }
    }
    printf("%s",s);
}