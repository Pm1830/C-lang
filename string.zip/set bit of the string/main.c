/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char s[20],*p=s;
     int i,q=0,a;
     unsigned int c;
    printf("enter the string=");
    scanf("%s",s);
    while(a=0,*p)
    {
        if(*p>=48 && *p<=59)
        {
            for(i=48,c=0;i<*p;i++,c++);
           for(i=31;i>=0;i--)
            if(c>>i&1)
            a++;
            printf("ste bits =%d ",a);
        }
        else
        {printf("%c=",*p);
                
                for(i=31;i>=0;i--)
                if(*p>>i&1)
            a++;
            printf("set bit =%d",a);
        }
        printf("\n");
        p++;
    }
}
