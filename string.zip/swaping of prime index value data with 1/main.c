#include<stdio.h>
void 
main () 
 { 
char s[20];
  
 
int i, j, c;
  
 
printf ("enter the string:");
  
 
scanf ("%[^\n]", s);
  
 
for (j = 0; s[j]; j++)
	
 
	{
	  
 
for (i = 1, c = 0; i <= j; i++)
		
 
		{
		  
 
if (j % i == 0)
			
 
c++;
		
 
}
	  
 
if (c == 2)
		
 
s[j] = '1';
	
 
}
  
 
printf ("%s", s);

 
}


