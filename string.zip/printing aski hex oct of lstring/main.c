#include<stdio.h>
void main()
{
    char s[50],*p=s;
    printf("enter the string=");
    scanf("%s",s);
    while(*p)
    {
         printf("asci of %c=%d\n",*p,*p);
        printf("hex of %c=%x\n",*p,*p);
        printf("oct of %c=%o\n",*p,*p);
        p++;
    }
    
}