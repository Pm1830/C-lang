#include<stdio.h>
void main()
{
    char s[50],*p=s;
    int c=0;
    printf("entr the string=");
    scanf("%s",s);
    while(*p)
    {
        c++;
        p++;
    }
    printf("len=%d ",c);
    
}