#include<stdio.h>
void main()
{
    char s[50],*ch=s;
    int i,len,l1,p;
    printf("enter the string=");
    scanf("%[^\n]",s);
    for(i=0;s[i];i++)
    {
        if(i==0)
        s[i]=s[i]-32;
        else if(s[i]==32)
        s[i+1]=s[i+1]-32;
    }
    printf("%s",s);
    
}