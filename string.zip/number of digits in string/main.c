#include<stdio.h>
void main()
{
    char s[50],*p=s;
    int c=0;
    printf("enter the char= ");
    scanf("%s",s);
    while(*p)
    {
        if(*p>=48 && *p<=58)
        c++;
        p++;
    }
    printf("len=%d",c);
}