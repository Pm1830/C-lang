#include<stdio.h>
#include<string.h>
void main()
{
    char s[50];
    int i,j,t,len;
    printf("enter the string=");
    scanf("%[^\n]",s);
   for(i=0;s[i];i++);
   len=i;
   for(i,j=0;i>j;j++,i--)
   {
       t=s[j];
       s[j]=s[i];
       s[i]=t;
   }
  for(j=0;s[j]!=32;j++);
   for(i=0,j;i<j;j--,i++)
   {
       t=s[j];
       s[j]=s[i];
       s[i]=t;
   }
   for(i=0;s[i];i++)
   printf("%c",s[i]);
   
  
}