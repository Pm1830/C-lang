#include<stdio.h>
void main()
{
    char s[10],b[10];
    int i,j;
    printf("enter two string=");
    scanf("%s%s",s,b);
    for(i=0;s[i];i++)
    {
        if(s[i]!=b[i])
        break;
    }
    if(s[i]==b[i])
    printf("same");
    else
    printf("not same");
}