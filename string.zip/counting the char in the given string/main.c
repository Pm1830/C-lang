#include<stdio.h>
int strscr(char *,char);
void main()
{
    char ch,s[50];
    int r;
    printf("enter the string=");
    scanf("%[^\n]",s);
    printf("enter the char=");
    scanf(" %c",&ch);
   r=strscr(s,ch);
   printf("the count=%d",r);
}
int strscr(char *p,char ch)
{ static int c;
    if(*p)
    {
        if(*p==ch)
        {c++;
        p++;
        strscr(p,ch);
        return c;
        }
        else
        {
            p++;
        return strscr(p,ch);
        }
        
        
    }
}