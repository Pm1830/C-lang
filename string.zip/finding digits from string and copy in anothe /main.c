#include<stdio.h>
void main()
{
    char s[10],b[10];
    int i,j;
    printf("enter the string: ");
    scanf("%s",s);
    for(i=0,j=0;s[i];i++)
    {
        if(s[i]>='0' && s[i]<='9')
        {b[j]=s[i];
        j++;}
    }
    printf("%s",b);
}