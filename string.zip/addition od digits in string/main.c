#include<stdio.h>
void main()
{
    char s[50],*p=s;
    int c,a;
    printf("enter the string=");
    scanf("%s",s);
    int sum=0;
    while(*p)
    {
        if(*p>=48 && *p<=59)
        {for(c=48,a=0;c<*p;c++,a++);
        sum=sum+a;}
        p++;
    }
    printf("sum=%d",sum);
}