#include<stdio.h>
void main()
{
    char s[50];
    gets(s);
    puts(s);
}