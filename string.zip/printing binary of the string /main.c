/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char s[20],*p=s;
     int i,q=0,ele;
     unsigned int c;
    printf("enter the string=");
    scanf("%s",s);
   // ele=sizeof(s)/sizeof(s[0]);
    //printf("%d\n",ele);
    while(*p)
    {
        if(*p>=48 && *p<=59)
        {
            for(i=48,c=0;i<*p;i++,c++);
            printf("%d=",c);
            for(i=31;i>=0;i--)
            printf("%d",c>>i&1);
        }
        else
        {printf("%c=",*p);
                 for(i=31;i>=0;i--)
            printf("%d",*p>>i&1);
        }
        printf("\n");
        p++;
    }
}
