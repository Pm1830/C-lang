#include<stdio.h>
void main()
{
    char s[50];
    int i,c;
    printf("enter the string=");
    scanf("%[^\n]",s);
    i=0;
    c=0;
    while(s[i])
    {
        if(s[i]==32)
        {
            printf("lenth=%d\n",c);
            c=c-(c+1);
            
        }
        c++;
        i++;
        
    }
    printf("lenth=%d\n",c);
}