#include<stdio.h>
void main()
{
    char s[10],b[10];
    int i;
    printf("enter the string=");
    scanf("%s",s);
    for(i=0;s[i];i++);
    for(i=i;s[i]>=0;i--)
    {
        if(s[i]=='p')
        printf("%d ",i);
        
    }
   
}