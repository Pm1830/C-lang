#include<stdio.h>
void main()
{
    char s[50],ch;
    int i,len,index;
    printf("enter the string=");
    scanf("%s",s);
    printf("enter the char =");
    scanf(" %c",&ch);
    printf("enter the index=");
    scanf("%d",&index);
    for(i=0;s[i];i++);
    //printf("%d\n",i);
    for(len=i+1;len>index;len--)
    {
        s[len]=s[len-1];
    }
    s[index]=ch;
    printf("%s",s);
    
}