#include<stdio.h>
   void main()
   {
   char s[20];
   int i,j;
   printf("enter string:");
   scanf("%s",s);
   for(i=0;s[i];i++)
   {
  for(j=1;s[j];j++)
  {
  if(s[i]==s[j])
  {if(i!=j)
  s[j]=1;
  }}}
  printf("%s",s);
  for(i=0;s[i];i++);
  printf("%d",i);
  }