#include<stdio.h>
void main()
{
    char s[20],ch,cha;
    int i,j;
    printf("enter the string:");
    scanf("%[^\n]",s);
    for(j=0;j<2;j++)
    {
    printf("enter the char you want ro replace:");
    scanf(" %c",&ch);
    printf("enter char:");
    scanf(" %c",&cha);
    for(i=0;s[i];i++)
    {
        if(s[i]==ch)
        {
            s[i]=cha;
        }
    }
    printf("%s\n",s);
}}