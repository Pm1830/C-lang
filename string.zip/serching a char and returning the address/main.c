#include<stdio.h>
#include"header.h"
void main()
{
    char s[50],ch;
    char *p,*q=s;
    pf("enter the string=");
    sf("%s",s);
    pf("enter the char=");
    sf(" %c",&ch);
    p=*serchar(s,ch);
   pf("%p\n",p);
   
    
    
}