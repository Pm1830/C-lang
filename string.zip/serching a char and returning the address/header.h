#define pf printf
#define sf scanf
char *serchar(char *p,char ch)
{
    while(*p)
    {
        if(*p==ch)
        return p;
        p++;
    }
    return (NULL);
}