#include<stdio.h>
#include<stdlib.h>
void main(int len,char **s)
{int a,b;
    //for(i=1,j=1;i<len;j++,i++)
    a=atoi(s[1]);
    b=atoi(s[3]);
    switch(*s[2]) 
    {
        case '+': printf("sum=%d",a+b);
                  break;
        case '-': printf("sub=%d",a-b);
                  break;
        case '*': printf("multi=%d",a*b);
                  break;
        case '/': printf("div=%d",a/b);
                  break;
        
    }
    }
