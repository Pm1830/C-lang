#include<stdio.h>
void strcat1(char *,char * );
void main()
{
    char s[50],a[50];
    printf("enter the first string=");
    scanf("%s",s);
    printf("enter the second string=");
    scanf("%s",a);
    strcat1(s,a);
    printf("%s",s);
}
void strcat1(char *p,char *q)
{
    int i,temp,j,w;
    for(i=0;p[i];i++);
    for(j=i,w=0;q[w];w++,j++)
    {
        p[j]=q[w];
    }
}