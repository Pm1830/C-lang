#include<stdio.h>
/*#define big(i,j) {if(i>j)\
                  printf(#i" is big");\
                  else \
                  printf(#j" is big");}*/
#define big(i,j) i>j?printf(#i" is big"):printf(#j " is big")
void main()
{
    int a=5,b=20;
    big(a,b);
}