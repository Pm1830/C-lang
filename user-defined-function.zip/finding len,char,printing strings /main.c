#include<stdio.h>
void stringprint(char *);
int len(char *,int );
void serchar(char *,char);
void main()
{
    char a[20],ch;
    int ele,c;
    ele=sizeof(a)/sizeof(a[0]);
    printf("enter the string=");
    scanf("%s",a);
    printf("enter the char you want to search=");
    scanf(" %c",&ch);
    stringprint(a);
   serchar(a,ch);
   c=len(a,ele);
   
    printf("length=%d\n",c);
}
void stringprint(char *p)
{
    for(int i=0;i<20;i++)
    printf("%c",p[i]);
    printf("\n");
}
int len(char *len,int c)
{
    for(c=0;len[c];c++);
    return c;
}
void serchar(char *ser,char ch)
{
    for(int l=0;ser[l];l++)
    {
        if(ser[l]==ch)
        for(int k=l;ser[k];k++)
        printf("%c",ser[k]);
       
    } printf("\n");
}