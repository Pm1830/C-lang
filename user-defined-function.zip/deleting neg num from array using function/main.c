#include<stdio.h>
int postive(int *,int );
void main()
{
    int a[4],ele,c,i;
    printf("enter the array=");
    ele=sizeof(a)/sizeof(a[0]);
    for(i=0;i<ele;i++)
    scanf("%d",&a[i]);
    
   c=postive(a,ele);
    for(i=0;i<ele-c;i++)
    printf("%d ,",a[i]);
}
int postive(int *p,int ele)
{int i,c=0,j;
    for(i=0;i<ele;i++)
    {
        if(p[i]<0)
        {c++;
            for(j=i;j<ele-1;j++)
            {
                p[j]=p[j+1];
                
            }i--;
        }
        
    }
return c;
}