#include<stdio.h>
int add(int ,int);
void main()
{
    int a,b,r;
    printf("enter two numbers=");
    scanf("%d %d",&a,&b);
    r=add(a,b);
    printf("sum=%d",r);
}
int add(int x,int y)
{int z;
    z=x+y;
    return z;
}