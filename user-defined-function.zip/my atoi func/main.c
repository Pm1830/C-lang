#include<stdio.h>
int my_atoi(char *);
void main()
{   int resul;
    char s[10];
    printf("enter the string =");
    scanf("%s",s);
    resul=my_atoi(s);
    printf("%d ",resul);
}
int my_atoi(char *p)
{int i,j,sum=0;
    for(;*p;p++)
   { if(*p>=48 && *p<=59)
    {for(i=48,j=0;i<*p;j++,i++);
    sum=sum*10+j;}
    else
    break;}
    return sum;
}