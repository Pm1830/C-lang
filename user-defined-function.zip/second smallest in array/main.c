#include<stdio.h>
int ssmall(int *,int );
void main()
{
    int a[5];
    int r,ele,i;
    ele=sizeof(a)/sizeof(a[0]);
    printf("enter the array=");
    for(i=0;i<ele;i++)
    scanf("%d",&a[i]);
    r=ssmall(a,ele);
    printf("smallest=%d",r);
}
int ssmall(int *p,int ele)
{ int i,s=p[0];
    for(i=1;i<ele;i++)
    if(p[i]<s)
    s=p[i];
    for(i=0;i<ele;i++)
    {if(s==p[i])
    continue;
    if(s>p[i])
    s=p[i];
    }
    return s;
    
}