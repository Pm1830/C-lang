#include<stdio.h>
char* mystrstr(char *,char *);
void main()
{
    char a[50],s[10],*p;
    printf("enter the string=");
    scanf("%s",a);
    printf("enter the sub string=");
    scanf("%s",s);
    p=mystrstr(a,s);
    printf("%s",p);
    
}
char* mystrstr(char *p,char *q)
{int c,j,i;
    for(i=0;p[i];i++)
    {
        if(q[0]==p[i])
        {
            for(j=i,c=0;q[c];c++,j++)
            if(p[j]!=q[c])
            return (0);
            break;
        }
        //else
        //return 0;
    }
    return (p+i);
}