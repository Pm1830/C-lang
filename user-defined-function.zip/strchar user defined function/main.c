#include<stdio.h>
char* mystr(char *,char );
void main()
{
    char s[40],*m;
    char ch;
    printf("enter the string=");
    scanf("%s",s);
    printf("enter the char=");
    scanf(" %c",&ch);
    m=mystr(s,ch);
    printf("%s",m);
    
}
char* mystr(char *p,char q)
{
    for(int i=0;p[i];i++)
    {
            if(p[i]==q)
            return (p+i);
        
    }
    return 0;
    
}