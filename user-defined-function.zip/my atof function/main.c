#include<stdio.h>
float my_atoi(char *);
void main()
{   float resul;
    char s[10];
    printf("enter the string =");
    scanf("%s",s);
    resul=my_atoi(s);
   printf("%f ",resul);
}
float my_atoi(char *p)
{int i,j,q,mul=1;
 float sum=0,sum1=0,c;
    for(;*p;p++)
   { 
       if(*p>=48 && *p<=59)
    {
        for(i=48,j=0;i<*p;j++,i++);
        sum=sum*10+j;
    }
    else
    break;}
    for(p=p,q=0;*p;q++,p++)
    {
        for(i=48,j=0;i<*p;j++,i++);
        sum1=sum1*10+j;
    }
    for(int i=0;i<q-1;i++)
    mul=mul*10;
        sum1=sum1/mul;
    c=sum+sum1;                                                                //printf("%f ",sum1);
      return c;                                                               //printf("%f\n ",sum1);
                                                                                  //c=(float)sum+sum1;
                                                                                  //  printf("%f",c);
                                                                                   
   
}