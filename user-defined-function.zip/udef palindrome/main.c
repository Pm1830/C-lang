#include<stdio.h>
int palindrome(int);
void main()
{
    int num,result;
    printf("enter the number =");
    scanf("%d",&num);
    result=palindrome(num);
    if(result==1)
    printf("palindrome");
    else
    printf("not");
}
int palindrome(int n)
{int rev,r,temp;

    for(temp=n;n;n=n/10)
    { r=n%10;
        rev=rev*10+r;
    }
    if(rev==temp)
    return 1;
    else
    return 0;
}