#include<stdio.h>
void main()
{
    int i,j,ch,k,c,row;
    printf("enter the row=");
    scanf("%d",&row);
    if(row>0){
    for(i=0;i<row;i++)
    {if(row>4){
        for(j=4;j>i;j--)
           {printf(" ");}}
        for(k=1,c=1,ch=65;k<=2*i+1;k++)
        {
            if(i%2==1)
            printf("%d",c++);
            else
            printf("%c",ch++);
        }
        printf("\n");
    }}
    else 
    printf("invalid input");
}