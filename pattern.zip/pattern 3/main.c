#include<stdio.h>
void main()
{
    int i,j,k,c,rows;
    printf("enter the number of rows=");
    scanf("%d",&rows);
    rows=rows;
    for(i=0;i<rows;i++)
    {   for(k=0;k<i*2;k++)
    {
        printf(" ");
    }
        for(j=rows,c=0;j>i*2;j--)
        {
            printf("%d ",c++);
        }
        printf("\n");
    }
}