#include<stdio.h>
void main()
{
    int i,j,k,p;
    char ch;
    for(i=0;i<6;i++)
    {
        for(j=4,ch=65;j>i;j--)
        {printf("%c",ch++);}
        for(k=1;k<=i;k++)
        printf(" ");
        for(k=1;k<=i;k++)
        printf(" ");
        for(p=4,ch=69;p>i;p--)
        printf("%c",ch++);
        printf("\n");
    }
    
}